import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zivotopis',
  templateUrl: './zivotopis.component.html',
  styleUrls: ['./zivotopis.component.css']
})
export class ZivotopisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
