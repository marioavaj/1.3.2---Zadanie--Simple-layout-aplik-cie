import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zivotopis',
  templateUrl: './zivotopis.component.html',
  styleUrls: ['./zivotopis.component.scss']
})
export class ZivotopisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
