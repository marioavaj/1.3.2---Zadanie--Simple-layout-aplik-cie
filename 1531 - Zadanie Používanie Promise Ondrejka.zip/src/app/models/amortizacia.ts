
export abstract class Amortizacia{
stupenAmortizacie: Number;


 Amortizacia (){}

}