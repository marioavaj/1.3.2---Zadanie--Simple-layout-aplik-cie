import { Amortizacia } from "./amortizacia";

export class firemneAuta  extends Amortizacia {
    modelAuta: String;

    zoznamAut = [
        { nazovAuta: "fabia", stupenAmortizacie: null },
        { nazovAuta: "felicia", stupenAmortizacie: null },
        { nazovAuta: "octavia", stupenAmortizacie: null },
        { nazovAuta: "scala", stupenAmortizacie: null },
        { nazovAuta: "superb", stupenAmortizacie: null },
        ];

        override Amortizacia (){


       };
    
}