export interface KartaZamestnanca{

meno: string;
PrideleneNaradie?: String;
PridelenyProjekt?: String;
prideleneAuto?:String

}