import { Amortizacia } from "./amortizacia";


export class Naradie extends Amortizacia {
    nazovNaradia: String;
    
    zoznamNaradia = [
        { nazovNaradia: "Vrtacka", stupeAmortizacie: null },
        { nazovNaradia: "zbijacka", stupeAmortizacie: null },
        { nazovNaradia: "kladivo", stupeAmortizacie: null },
        { nazovNaradia: "srobovacka", stupeAmortizacie: null },
        ]

        Amortizacia (){};
}
