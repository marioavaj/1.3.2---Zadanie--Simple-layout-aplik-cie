
export class RozpracovaneProjetky {
    NazovProjektu: String;
    
    zoznamProjektov = ['dialnicaD1', 'skola', 'chodnik', 'telocvicna']

}
