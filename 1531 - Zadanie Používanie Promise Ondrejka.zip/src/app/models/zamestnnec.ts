import {KartaZamestnanca} from "./kartaZamestnanca";


export class Zamestnanec {
    meno : string;
    PrideleneNaradie?: String;
    PridelenyProjekt?: String;
    prideleneAuto?: String
}
