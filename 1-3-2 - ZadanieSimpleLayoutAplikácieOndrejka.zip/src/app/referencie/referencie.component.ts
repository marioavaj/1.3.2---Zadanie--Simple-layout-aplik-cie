import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-referencie',
  templateUrl: './referencie.component.html',
  styleUrls: ['./referencie.component.css']
})
export class ReferencieComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
