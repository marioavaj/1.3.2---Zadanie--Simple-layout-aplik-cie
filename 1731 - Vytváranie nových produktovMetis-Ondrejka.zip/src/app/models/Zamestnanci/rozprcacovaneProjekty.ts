
export class RozpracovaneProjetky {
    nazovProjektu: string;

    constructor(nazovProjektu: string){
        this.nazovProjektu = nazovProjektu

    }

}
