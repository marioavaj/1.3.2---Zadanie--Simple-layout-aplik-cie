import { SortByPipePipe } from './sort-by-pipe.pipe';

describe('SortByPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SortByPipePipe();
    expect(pipe).toBeTruthy();
  });
});
