export abstract class Amortizacia {
    stupenAmortizacie: number;
    evidencneCislo: number;
    nazov: string;

    vypocetAmortizacie() {}


}
