export interface KartaZamestnanca{

meno: string;
prideleneNaradie?: string;
pridelenyProjekt?: string;
prideleneAuto?:string

}