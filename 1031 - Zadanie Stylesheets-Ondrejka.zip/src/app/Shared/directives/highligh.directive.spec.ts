import { HighlighDirective } from './highligh.directive';

describe('HighlighDirective', () => {
  it('should create an instance', () => {
    const directive = new HighlighDirective();
    expect(directive).toBeTruthy();
  });
});
