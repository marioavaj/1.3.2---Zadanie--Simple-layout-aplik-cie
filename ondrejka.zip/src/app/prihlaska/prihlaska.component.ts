import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prihlaska',
  templateUrl: './prihlaska.component.html',
  styleUrls: ['./prihlaska.component.scss']
})
export class PrihlaskaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
